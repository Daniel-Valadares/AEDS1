748377_Daniel_Valadares_De_Souza_Felix

Professor tive bastante dificuldade no guia 0314 e 0315. Não consegui finalizar a tarefa proposta, gostaria que o senhor olha-se o que eu fiz de errado para ter ciência do que devo evitar na proxima tentativa.

0314-> Consegui realizar a coleta e retornar ao ponto inicial, além disso consegui salvar um mapa e o exibir no final. Porém, não consegui deixar marcado no mapa o percurso feito. Tentei modificar os blocos do mapWorld(), saveMap () e readMap(); entretanto não conseguir chegara na solução. O que deveria ser feito para evitar isso?

0315-> Não consegui separar o "robot" em "robot1" e "robot2". Tentei por varios metodos, ate mesmo copiei a biblioteca do karel e tentei renomear para tudo la dentro de modo que ficasse uma nova biblioteca chamada jarel e uma nova classe robot2, mas tudo sem o retorno esperado, como essa separação deveria ser feita? 

E por ultimo gostaria de saber se o senhor gostaria do reenvio da atividade corrigida? Sei que de acordo com o canvas, não é avaliativa, mas mesmo assim não entreguei o prometido, e gostaria se saber o que preferiria quanto a essa questão. No mais é isso, desculpe pela entrega imperfeita e obrigado desde já.