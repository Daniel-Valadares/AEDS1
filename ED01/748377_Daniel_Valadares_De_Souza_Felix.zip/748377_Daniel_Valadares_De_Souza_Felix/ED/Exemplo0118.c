/*
 Exemplo0118 - v0.0. - __ / __ / _____
 Author: 748377_Daniel_Valadares_De_Souza_Felix

 Para compilar em terminal (janela de comandos):
 Linux :  gcc -o Exemplo0118     Exemplo0118.c
 Windows: gcc -o Exemplo0118.exe Exemplo0118.c
 Para executar em terminal (janela de comandos):
 Linux : ./Exemplo0118
 Windows:  Exemplo0118
*/
// dependencias
#include "io.h" // para definicoes proprias ( na mesma pasta )
/*
 Funcao principal.
 @return codigo de encerramento
 @param argc - quantidade de parametros na linha de comandos
 @param argv - arranjo com o grupo de parametros na linha de comandos
*/
int main(int argc, char *argv[])
{
  // definir dado
  double comprimento = 0;  // definir variavel real de comprimento de um paralelepipedo
  double largura     = 0;  // definir variavel real de largura de um paralelepipedo
  double altura      = 0;  // definir variavel real de altura de um paralelepipedo
  double volume      = 0;  // definir variavel real do volume de um paralelepipedo
                           // identificar
  printf("\n%s\n", "Exemplo0118 - Programa = v0.0");
  printf("%s\n", "Autor: 748377_Daniel_Valadares_De_Souza_Felix");

  // ler do teclado o valor inteiro
  printf("\n\n%s", "Entrar com um valor real, equivalente ao comprimento de um paralelepipedo: ");
  scanf("%lf", &comprimento); // valor da paralelepipedo
  printf("\n%s", "Agora, com um valor real, insira um valor equivalente a largura de um paralelepipedo: ");
  scanf("%lf", &largura);     // valor da largura
  printf("\n%s", "Por ultimo, com um valor real, insira um valor equivalente a altura de um paralelepipedo: ");
  scanf("%lf", &altura);      // valor da altura

  // calculos
  comprimento = comprimento*4;
  largura     = largura*4;
  altura      = altura*4;
  volume      = comprimento*largura*altura;

  // mostrar resultados do calculo
  printf("\n%s%lf%s%lf%s%lf%s\n\n", "Um paralelepipedo com quatro vezes o valor do comprimento, da largura e da altura; inseridos, que respectivamente equivalem a ", 
          comprimento, ", ", largura, " e ", altura, ", e possui:");
  printf("\t%s%lf", "Um volume igual a ", volume);

  // encerrar
  printf("\n\nApertar ENTER para terminar.");
  fflush(stdin); // limpar a entrada de dados
  getchar();     // aguardar por ENTER
  return (0);    // voltar ao SO (sem erros)
} // fim main( )
/*
---------------------------------------------- documentacao complementar
---------------------------------------------- notas / observacoes / comentarios
---------------------------------------------- previsao de testes
---------------------------------------------- historico
Versao Data Modificacao6
0.1  __/__ esboco
0.2  __/__ mudanca de versao para double
0.3  __/__ mudanca de versao para char
0.4  __/__ mudanca de versao para bool
0.5  __/__ mudanca de versao para string
0.6  __/__ mudanca de versao para multiplos int
0.7  __/__ mudanca de versao para pow
0.8  __/__ adaptação de versao para biblioteca string.h
0.9  __/__ adaptação de versao para printf
0.10 __/__ adaptação de versao para biblioteca io.h
0.11 __/__ teste de calculo com quadrado
0.12 __/__ mudança de teste de calculo com quadrado
0.13 __/__ teste de calculo com retangulo
0.14 __/__ mudança de teste de calculo com retangulo
0.15 __/__ teste de calculo com triangulo
0.16 __/__ mudança de teste de calculo com triangulo
0.17 __/__ teste de calculo com cubo
0.18 __/__ teste de calculo com paralelepipedo
---------------------------------------------- testes
Versao Teste
0.1  01. ( OK ) identificacao de programa leitura e exibicao de inteiro
0.2  01. ( OK ) identificacao de programa com double
0.3  01. ( OK ) identificacao de programa com char
0.4  01. ( OK ) identificacao de programa com bool
0.5  01. ( OK ) identificacao de programa com string
0.6  01. ( OK ) identificacao de programa com multiplos int
0.7  01. ( OK ) identificacao de programa com pow
0.8  01. ( OK ) identificacao de programa com biblioteca string.h
0.9  01. ( OK ) identificacao de programa com printf
0.10 01. ( OK ) identificacao de programa com biblioteca io.h
0.11 01. ( OK ) teste de calculo da terca parte de um quadrado
0.12 01. ( OK ) teste de calculo do perimetro e da area de um quadrado
0.13 01. ( OK ) teste de calculo da quarta parte de um retangulo
0.14 01. ( OK ) teste de calculo do perimetro e da area de um retangulo
0.15 01. ( OK ) teste de calculo com triangulo
0.16 01. ( OK ) teste de calculo da altura, do perimetro e da area de um triangulo
0.17 01. ( OK ) teste de calculo com cubo
0.18 01. ( OK ) teste de calculo com paralelepipedo
*/